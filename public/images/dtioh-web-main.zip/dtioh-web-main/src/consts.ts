// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = `Dr. Tasneem's Institute of Health`;
export const SITE_DESCRIPTION = "Professional healthcare and aesthetic training institute offering accredited certification programs in Pakistan.";
